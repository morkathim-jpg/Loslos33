# Image Forge

A polished Next.js starter for an AI image-generation app.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Connect a provider

Implement the provider request in `app/api/generate/route.js`. Keep credentials in environment variables and follow the provider's current API and safety requirements.

The UI already sends:
- prompt
- negative prompt
- style
- aspect ratio
- image count

The API route should return `{ "images": ["https://..."] }`.

This starter does not attempt to disable or bypass provider safety systems.
