import { NextResponse } from "next/server";

/*
  Provider adapter:
  Put your provider call here. Keep the API key server-side.

  Expected response:
    { images: ["https://...", "https://..."] }

  The starter intentionally does not bypass provider safety systems.
*/

export async function POST(request) {
  const body = await request.json();
  const { prompt, negative, style, ratio, count } = body;

  if (!prompt?.trim()) {
    return NextResponse.json({error:"Prompt is required."}, {status:400});
  }

  // Demo mode: replace this section with your provider SDK/API call.
  // Example shape:
  // const result = await provider.generate({ prompt, negative, style, ratio, count });
  // return NextResponse.json({ images: result.images });

  return NextResponse.json({
    error: "Demo mode: connect an image-generation provider in app/api/generate/route.js."
  }, {status:501});
}