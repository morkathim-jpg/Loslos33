import "./globals.css";

export const metadata = {
  title: "Image Forge",
  description: "A modern AI image generation interface"
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}