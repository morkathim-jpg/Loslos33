"use client";

import { useState } from "react";

const presets = ["Photorealistic", "Cinematic", "Anime", "Illustration", "3D Render", "Watercolor"];

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [negative, setNegative] = useState("");
  const [style, setStyle] = useState("Photorealistic");
  const [ratio, setRatio] = useState("1:1");
  const [count, setCount] = useState(1);
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState([]);

  async function generate() {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({ prompt, negative, style, ratio, count })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Generation failed");
      setImages(data.images || []);
    } catch (e) {
      alert(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="shell">
      <header>
        <div>
          <div className="eyebrow">AI CREATIVE STUDIO</div>
          <h1>Image Forge</h1>
          <p>Turn ideas into images with a clean, flexible generation workspace.</p>
        </div>
        <div className="badge">● Ready</div>
      </header>

      <section className="workspace">
        <aside className="panel controls">
          <label>Prompt</label>
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)}
            placeholder="Describe the image you want to create..." rows={7}/>

          <label>Negative prompt <span>optional</span></label>
          <input value={negative} onChange={e=>setNegative(e.target.value)}
            placeholder="Things to avoid..." />

          <label>Style</label>
          <div className="chips">
            {presets.map(p=><button key={p} className={style===p?"active":""}
              onClick={()=>setStyle(p)}>{p}</button>)}
          </div>

          <div className="grid2">
            <div><label>Aspect ratio</label>
              <select value={ratio} onChange={e=>setRatio(e.target.value)}>
                <option>1:1</option><option>16:9</option><option>4:3</option><option>3:4</option><option>9:16</option>
              </select>
            </div>
            <div><label>Images</label>
              <select value={count} onChange={e=>setCount(Number(e.target.value))}>
                <option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option>
              </select>
            </div>
          </div>

          <button className="generate" disabled={loading || !prompt.trim()} onClick={generate}>
            {loading ? "Generating…" : "Generate images →"}
          </button>
          <small>Connect your image provider in <code>app/api/generate/route.js</code>.</small>
        </aside>

        <section className="gallery">
          {images.length ? images.map((src,i)=>
            <figure key={i}><img src={src} alt={`Generated result ${i+1}`}/>
              <a href={src} download={`image-${i+1}.png`}>Download</a></figure>
          ) : <div className="empty"><div className="spark">✦</div><h2>Your creations appear here</h2>
            <p>Enter a prompt and generate your first image.</p></div>}
        </section>
      </section>
    </main>
  );
}